from django.db import models
from django.utils.text import slugify

class Author(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    profile_image = models.ImageField(upload_to='authors/', blank=True)  # Store images in the 'authors/' directory
    slug = models.SlugField(unique=True, blank=True)  

    def __str__(self):
        return self.name