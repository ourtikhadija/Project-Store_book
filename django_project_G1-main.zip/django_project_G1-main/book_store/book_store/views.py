from django.shortcuts import render
from django.http import HttpResponse
from books.models import Book

def homepage(request):
    
    hero_book = Book.objects.order_by('-id').first()  
     
    featured_books = Book.objects.order_by('-id')[:4]
    
    best_selling_book = Book.objects.order_by('?').first()  # Get a random book  

    context = {
        'hero_book': hero_book,
        'featured_books': featured_books,
        'best_selling_book': best_selling_book
    }

    return render(request, 'home.html', context)

def aboutpage(request):
    # return HttpResponse('Home page')
    return render(request, 'about.html') 
