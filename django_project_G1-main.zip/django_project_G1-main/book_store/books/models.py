from django.db import models
from authors.models import Author
# Create your models here.
class Book(models.Model):
    title  = models.CharField(max_length = 200)
    description = models.TextField(null=True, blank=True)
    price = models.FloatField(null=True, blank=True)
    slug = models.SlugField(default='book-test') 
    image = models.ImageField(upload_to='books/', blank=True, null=True)
    book_available = models.BooleanField(default=False)
    date = models.DateTimeField(auto_now_add=True)
    
    # Add a ForeignKey field to link the book to an author
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='books',default=1)  # One author can have many books

    def __str__(self):
        return self.title

class Order(models.Model):
    product = models.ForeignKey(Book, on_delete=models.SET_NULL, null=True)
    quantity = models.IntegerField(default=1)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.quantity} x {self.product.title}'