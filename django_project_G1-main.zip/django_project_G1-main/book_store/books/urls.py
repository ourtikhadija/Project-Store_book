from django.urls import path
from . import views
app_name = 'books'
urlpatterns = [
    path('', views.books_list, name='list'),
    path('<slug:slug>', views.book_detail, name='detail'),
    path('add-to-cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart-summary/', views.cart_summary, name='cart_summary'),
    path('checkout/', views.checkout, name='checkout'),
    path('order-complete/', views.order_complete, name='order_complete'),
]  