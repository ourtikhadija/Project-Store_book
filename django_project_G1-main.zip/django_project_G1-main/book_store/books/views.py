from django.shortcuts import render, get_object_or_404, redirect
from .models import Book, Order
# Create your views here.
def books_list(request):
    books= Book.objects.all().order_by('-date')
    return render(request, 'books/books_list.html', {'books': books})

def book_detail(request, slug):
    book = Book.objects.get(slug=slug)
    return render(request, 'books/book_detail.html', {'book': book})

def add_to_cart(request, book_id):
    book = get_object_or_404(Book, id=book_id)  # Retrieve the book
    quantity = int(request.POST.get('quantity', 1))  # Get quantity from the form (default is 1)

    # Get the cart from the session, or create a new one if it doesn't exist
    cart = request.session.get('cart', {})

    # If the book is already in the cart, update its quantity
    if str(book_id) in cart:
        cart[str(book_id)]['quantity'] += quantity
    else:
        # Add the book to the cart
        cart[str(book_id)] = {
            'title': book.title,
            'price': str(book.price),
            'quantity': quantity,
            'image_url': book.image.url if book.image else None,
        }

    # Save the updated cart back into the session
    request.session['cart'] = cart

    # Redirect to the cart summary page
    return redirect('books:cart_summary')

def cart_summary(request):
    # Get the cart from the session or initialize an empty cart
    cart = request.session.get('cart', {})
    
    return render(request, 'books/cart_summary.html', {'cart': cart})

def checkout(request):
    cart = request.session.get('cart', {})

    # Create an order for each item in the cart
    for item_id, item in cart.items():
        book = get_object_or_404(Book, id=item_id)
        Order.objects.create(
            product=book,
            quantity=item['quantity']
        )

    # Clear the cart after the order is placed
    request.session['cart'] = {}

    return redirect('books:order_complete')

def order_complete(request):
    return render(request, 'books/order_complete.html')